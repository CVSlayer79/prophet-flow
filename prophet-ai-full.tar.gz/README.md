# 🚀 ProphetAI: Operations Manual

Welcome to your new SaaS! This guide ensures everything runs smoothly for you and your subscribers.

## 🛠 One-Time Setup (For No Problems)
1. **Stripe Portal:** Go to your Stripe Dashboard > Settings > Customer Portal. Enable "Cancellations" and "Plan Changes." Copy the link and paste it into `index.html` (I've already put a placeholder for you).
2. **GitHub Deployment:** Push this entire folder to GitHub. Connect it to Vercel. Your landing page is now live!
3. **Database Security:** The `leads.db` stays on your server. To keep subscribers happy, the `server.js` serves them the data they pay for.

## 🔄 Daily Routine (The Profit Cycle)
Run the AI scanner daily to find new leads:
```bash
node src/autopilot.js MD "Baltimore"
```
The AI will:
- Scrape Zillow/Craigslist/Facebook.
- Calculate the MAO automatically.
- Save it to your database.
- **Auto-Notify:** Send an alert to your subscribers if the profit is over $5,000.

## 🌍 Expanding Globally
To start selling in the UK or Canada:
1. Open `src/real_scraper.js` and add the new country code.
2. Update the Pricing Section in `index.html` with a Stripe link for that currency.

## 🛡 Avoiding Disputes
- **Transparency:** The "Manage Subscription" link I added to your footer is your best defense. If a user wants to cancel, they can do it in 2 clicks.
- **Accuracy:** The AI math uses the 70% Rule. Always remind subscribers to "verify the numbers" in your legal footer.

**You are now in business!**
